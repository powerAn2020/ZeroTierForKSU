#!/system/bin/sh
MODDIR=${0%/*}

if [ -f "/data/adb/ksu/bin/busybox" ]; then
  # busybox KSU
  busybox="/data/adb/ksu/bin/busybox"
elif [ -f "/data/adb/ap/bin/busybox" ]; then
  # busybox APatch
  busybox="/data/adb/ap/bin/busybox"
else
  # busybox Magisk
  busybox="/data/adb/magisk/busybox"
fi

ZTPATH=/data/adb/zerotier
MANUAL=/data/adb/zerotier/MANUAL
PIDFILE=$ZTPATH/zerotier-one.pid
ZEROTIERD=$MODDIR/zerotier-one
SECRETFILE=$ZTPATH/authtoken.secret

start_service() {
  zpid=$(pgrep -f "zerotier-one")
  if [ -z $zpid ];then
    # Start ZEROTIERD
    if [ ! -f $MANUAL ]; then
      echo "starting $ZEROTIERD... \c"
      $ZEROTIERD -d $ZTPATH
      sshd_rc=$?
      if [ $sshd_rc -ne 0 ]; then
        echo "$0: Error ${sshd_rc} starting ${ZEROTIERD}... bailing."
        exit $sshd_rc
        # else
        # 加入ip路由规则
        #  ip rule add from all lookup main pref 18
      fi
    else
      echo "service run manual"
    fi
  else
    echo "service is running,pid:$zpid"
  fi
  echo done.
}
(
    until [ $(getprop init.svc.bootanim) = "stopped" ]; do
        sleep 10
    done
    start_service
)&