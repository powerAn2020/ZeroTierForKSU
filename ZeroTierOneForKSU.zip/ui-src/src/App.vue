<template>
  <router-view></router-view>

    <van-tabbar route>
      <van-tabbar-item replace to="/" icon="home-o">首页</van-tabbar-item>
      <van-tabbar-item replace to="/plant" icon="fire-o">私有plant</van-tabbar-item>
      <van-tabbar-item replace to="/setting" icon="setting-o">设置</van-tabbar-item>
    </van-tabbar>

</template>

<script >
</script>

<style lang="less"></style>
