<template>
  <div>
    <van-empty
  image-size="80"
  description="咕咕咕"
/>
  </div>
</template>

<script>
import { ref } from 'vue';
import { exec } from 'kernelsu';

export default {
  setup() {
    const enable = ref(true);
    const checked = ref(true);
    const autoStart = ref(false);
    const uninstallKeep = ref(true);
    const enableLoading = ref(false);
    const checkedLoading = ref(false);
    const autoStartLoading = ref(false);
    const uninstallKeepLoading = ref(false);

    const execCmd = async (cmd) => {
      const { errno, stdout, stderr } = await exec(cmd, { cwd: '/tmp' });
      if (errno === 0) {
        // success
        console.log(stdout);
        return stdout;
      } else {
        console.info(stderr)
      }
    }
    const autoStartSwitch = (newValue) => {
      autoStartLoading.value=true;
      if(newValue===true){
        console.info('开启开机自启服务')
        execCmd('rm /data/adb/zerotier/MANUAL')
      }else{
        console.info('关闭开机自启服务')
        execCmd('touch /data/adb/zerotier/MANUAL')
      }
      autoStartLoading.value=false;
    };
    const uninstallKeepSwitch = (newValue) => {
      uninstallKeepLoading.value=true;
      if(newValue===true){
        console.info('开启卸载保留数据')
        execCmd('touch /data/adb/zerotier/KEEP_ON_UNINSTALL')
      }else{
        console.info('关闭卸载保留数据')
        execCmd('rm /data/adb/zerotier/KEEP_ON_UNINSTALL')
      }
      uninstallKeepLoading.value=false;
    };
    const enableSwitch = (newValue) => {
      enableLoading.value=true;
      if(newValue===true){
        console.info('启动zerotier')
        execCmd('sh /data/adb/modules/zerotier.sh start')
      }else{
        console.info('关闭zerotier')
        execCmd('sh /data/adb/modules/zerotier.sh stop')
      }
      enableLoading.value=false;
    };
    return {
      checked,
      enable,
      autoStart,
      uninstallKeep,
      checkedLoading,
      enableLoading,
      autoStartLoading,
      uninstallKeepLoading,
      uninstallKeepSwitch,
      enableSwitch,
      autoStartSwitch,
      execCmd
    };
  },
};
</script>